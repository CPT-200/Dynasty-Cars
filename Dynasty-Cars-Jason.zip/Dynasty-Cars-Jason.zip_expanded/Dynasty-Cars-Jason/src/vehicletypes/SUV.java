package vehicletypes;

public class SUV extends Car {
	public SUV() {} // Default Constructor
	public SUV(String brand, String model, String color, String fuelType, int mpg) { 
		super(brand, model, color, fuelType, mpg);
	}
}

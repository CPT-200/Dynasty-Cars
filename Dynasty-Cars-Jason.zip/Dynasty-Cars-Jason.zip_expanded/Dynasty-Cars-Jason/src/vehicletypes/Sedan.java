package vehicletypes;

public class Sedan extends Car {
	public Sedan() {} //Default Constructor
	public Sedan(String brand, String model, String color, String fuelType, int mpg) { 
		super(brand, model, color, fuelType, mpg);
	}
}

package vehicletypes;

public class Coupe extends Car {
	public Coupe() {} //Default Constructor
	public Coupe(String brand, String model, String color, String fuelType, int mpg) { 
		super(brand, model, color, fuelType, mpg);
	}
}

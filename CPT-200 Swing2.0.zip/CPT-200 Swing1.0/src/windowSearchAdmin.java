

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class windowSearchAdmin extends JFrame {

	private JPanel contentPane;
	private JComboBox brandBox;
	private JComboBox typeBox;
	private JComboBox convertBox;
	private JComboBox fuelBox;
	private JComboBox MPGBox;
	private JButton findBtn;
	private JButton backMenuBtn;
	private JLabel label;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					windowSearchAdmin frame = new windowSearchAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public windowSearchAdmin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSearch = new JLabel("Search");
		lblSearch.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSearch.setBounds(187, 11, 60, 37);
		contentPane.add(lblSearch);
		
		JLabel lblNewLabel = new JLabel("Enter Search Parameters:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(68, 68, 140, 14);
		contentPane.add(lblNewLabel);
		
		String[] color = {"Color", "Blue", "Red", "Green"};
		String[] brand = {"Brand", "Toyota", "Dodge", "Ram"};
		String[] type = {"Type", "SUV", "Truck", "Coupe"};
		String[] MPG = {"MPG", "70-45", "44-35", "34-25", "24-10"};
		String[] convert = {"Convertible", "Yes", "No"};
		String[] fuel = {"Fuel type", "Gasoline", "Diesel"};
		
		JComboBox colorBox = new JComboBox(color);
		colorBox.setToolTipText("Color");
		colorBox.setBounds(260, 124, 86, 20);
		contentPane.add(colorBox);
		
		brandBox = new JComboBox(brand);
		brandBox.setToolTipText("Brand");
		brandBox.setBounds(68, 93, 86, 20);
		contentPane.add(brandBox);
		
		typeBox = new JComboBox(type);
		typeBox.setToolTipText("Type");
		typeBox.setBounds(164, 93, 86, 20);
		contentPane.add(typeBox);
		
		convertBox = new JComboBox(convert);
		convertBox.setToolTipText("Convertible");
		convertBox.setBounds(164, 124, 86, 20);
		contentPane.add(convertBox);
		
		fuelBox = new JComboBox(fuel);
		fuelBox.setToolTipText("Fuel Type");
		fuelBox.setBounds(68, 124, 86, 20);
		contentPane.add(fuelBox);
		
		MPGBox = new JComboBox(MPG);
		MPGBox.setToolTipText("MPG");
		MPGBox.setBounds(260, 93, 86, 20);
		contentPane.add(MPGBox);
		
		findBtn = new JButton("Find");
		findBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				//Access database to perform search function
				JOptionPane.showMessageDialog(contentPane, "Searching Database for the Perfect Vehicle");
				windowSearchDisplayAdmin nextWindow = new windowSearchDisplayAdmin();
				nextWindow.setVisible(true);
				dispose();
			}
		});
		findBtn.setBounds(161, 169, 89, 23);
		contentPane.add(findBtn);
		
		backMenuBtn = new JButton("Back");
		backMenuBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				windowMenuAdmin previousWindow = new windowMenuAdmin();
				previousWindow.setVisible(true);
				dispose();
			}
		});
		backMenuBtn.setBounds(10, 227, 86, 23);
		contentPane.add(backMenuBtn);
		
		label = new JLabel("Admin Controls");
		label.setBounds(10, 11, 96, 14);
		contentPane.add(label);
	}

}

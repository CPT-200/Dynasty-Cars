
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class windowMenuAdmin extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					windowMenuAdmin frame = new windowMenuAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public windowMenuAdmin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblMainMenu = new JLabel("Main Menu");
		lblMainMenu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblMainMenu.setBounds(169, 11, 96, 37);
		contentPane.add(lblMainMenu);
		
		JLabel searchLabel = new JLabel("Search");
		searchLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		searchLabel.setBounds(66, 75, 142, 17);
		contentPane.add(searchLabel);
		
		JLabel lblDisplayTotalInventory = new JLabel("Display Total Inventory");
		lblDisplayTotalInventory.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDisplayTotalInventory.setBounds(66, 100, 142, 17);
		contentPane.add(lblDisplayTotalInventory);
		
		JLabel lblLogOut = new JLabel("Log Out");
		lblLogOut.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblLogOut.setBounds(66, 125, 142, 17);
		contentPane.add(lblLogOut);
		
		JLabel lblExit = new JLabel("Exit");
		lblExit.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblExit.setBounds(66, 150, 142, 17);
		contentPane.add(lblExit);
		
		JButton searchBtn = new JButton("Go");
		searchBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				windowSearchAdmin nextWindow = new windowSearchAdmin();
				nextWindow.setVisible(true);
				dispose();
			}
		});
		searchBtn.setBounds(246, 74, 89, 23);
		contentPane.add(searchBtn);
		
		JButton displayBtn = new JButton("Go");
		displayBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				windowDisplayAdmin nextWindow = new windowDisplayAdmin();
				nextWindow.setVisible(true);
				dispose();
			}
		});
		displayBtn.setBounds(246, 99, 89, 23);
		contentPane.add(displayBtn);
		
		JButton logOutBtn = new JButton("Go");
		logOutBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				JOptionPane.showMessageDialog(contentPane, "Logging out");
				windowLogin previousWindow = new windowLogin();
				previousWindow.setVisible(true);
				dispose();
			}
		});
		logOutBtn.setBounds(246, 124, 89, 23);
		contentPane.add(logOutBtn);
		
		JButton exitBtn = new JButton("Go");
		exitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				JOptionPane.showMessageDialog(contentPane, "Closing Program");
				System.exit(0);
			}
		});
		exitBtn.setBounds(246, 149, 89, 23);
		contentPane.add(exitBtn);
		
		JLabel lblNewLabel = new JLabel("Admin Controls");
		lblNewLabel.setBounds(10, 11, 96, 14);
		contentPane.add(lblNewLabel);
	}
}

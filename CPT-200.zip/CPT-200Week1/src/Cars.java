
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;



public abstract class Cars {
		// data fields
	private String car_Make;
	private String car_Model;
	private String car_Type;
	private int car_Year;
	private String car_Description;
	private boolean car_Transmission;
	private int car_Cylinder;
	
	Scanner scnr = new Scanner(System.in);
	
	public void cars() {}
	
	
	//getters and setters
	
	public String getMake() { return car_Make;}
	public String getModel() {return car_Model;}
	public String getType() {return car_Type;}
	public int getYear() {return car_Year;}
	public String getDescription() {return car_Description;}
	public boolean getTransmission() {return true;}
	public int getCylinder() {return car_Cylinder;}
	
	public void setMake(String car_Make) {this.car_Make = car_Make;}
	public void setModel(String car_Model) {this.car_Model = car_Model;}
	public void setType(String car_Type) {this.car_Type = car_Type;}
	public void setYear(int car_Year) {this.car_Year = car_Year;}
	public void setDescription(String car_Description) {this.car_Description = car_Description;}
	public void setTransmission(boolean car_Transmission) {this.car_Transmission = car_Transmission;}
	public void setCylinder(int car_Cylinder) {this.car_Cylinder = car_Cylinder;}
	
	// Methods
	
	public void addCar() {
	
		
		
		System.out.println("Enter Make: "); 
		setMake(scnr.next());
		System.out.println("Enter Model: ");
		setModel(scnr.next());
		System.out.println("Enter Type: ");
		setType(scnr.next());
		System.out.println("Enter Year: ");
		setYear(scnr.nextInt());
		System.out.println("Enter Description: ");
		setDescription(scnr.next());
		System.out.println("Enter Transmission: ");
		setTransmission(scnr.nextBoolean());
		System.out.print("Enter Cylinder: ");
		setCylinder(scnr.nextInt());
		
	}
	
	public void deleteCar(String make, String model, int year) { 
		make = getMake();
		model = getModel();
		year = getYear();
	}
	
	public void editDescription(String description) {
		description = getDescription();
		System.out.print("Enter new Description: ");
		setDescription(scnr.next());
		}
	}
     // end class Cars

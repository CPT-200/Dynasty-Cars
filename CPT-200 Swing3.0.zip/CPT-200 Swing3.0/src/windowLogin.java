import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class windowLogin extends JFrame {

	private JPanel contentPane;
	private JTextField usernameBox;
	private JTextField passwordBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					windowLogin frame = new windowLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public windowLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel title = new JLabel("Dynasty Cars Inventory System");
		title.setFont(new Font("Tahoma", Font.PLAIN, 20));
		title.setBounds(70, 11, 294, 42);
		contentPane.add(title);
		
		JLabel loginLabel = new JLabel("Login");
		loginLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		loginLabel.setBounds(194, 60, 46, 19);
		contentPane.add(loginLabel);
		
		JLabel usernameLabel = new JLabel("Username");
		usernameLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		usernameLabel.setBounds(234, 91, 68, 14);
		contentPane.add(usernameLabel);
		
		JLabel passwordLabel = new JLabel("Password");
		passwordLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		passwordLabel.setBounds(234, 116, 68, 14);
		contentPane.add(passwordLabel);
		
		usernameBox = new JTextField();
		usernameBox.setBounds(319, 90, 86, 20);
		contentPane.add(usernameBox);
		usernameBox.setColumns(10);
		
		passwordBox = new JTextField();
		passwordBox.setColumns(10);
		passwordBox.setBounds(319, 115, 86, 20);
		contentPane.add(passwordBox);
		
		JButton adminLoginButton = new JButton("Enter");
		adminLoginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String uname = usernameBox.getText();
				String pword = passwordBox.getText();
				
				if(uname.equals("admin") && pword.equals("password")) {
					JOptionPane.showMessageDialog(contentPane, "Admin Logged in Succesfully");
					windowMenuAdmin nextWindow = new windowMenuAdmin();
					nextWindow.setVisible(true);
					dispose();
				}else
				{
					JOptionPane.showMessageDialog(contentPane, "Incorrect username or password. Please try again.");
				}
			}
		});
		adminLoginButton.setBounds(256, 141, 89, 23);
		contentPane.add(adminLoginButton);
		
		JLabel guestLabel = new JLabel("Guest Login");
		guestLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		guestLabel.setBounds(70, 90, 75, 17);
		contentPane.add(guestLabel);
		
		JButton guestLoginButton = new JButton("Enter");
		guestLoginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				windowSearch nextWindowGuest = new windowSearch();
				nextWindowGuest.setVisible(true);
				dispose();
			}
		});
		guestLoginButton.setBounds(66, 141, 89, 23);
		contentPane.add(guestLoginButton);
	}
}

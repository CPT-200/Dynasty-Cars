

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class windowDisplayAdmin extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					windowDisplayAdmin frame = new windowDisplayAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public windowDisplayAdmin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel displayAll = new JLabel("Somehow collect and display all data from database");
		displayAll.setBounds(86, 117, 315, 14);
		contentPane.add(displayAll);
		
		JLabel totalInventory = new JLabel("Entire Inventory");
		totalInventory.setFont(new Font("Tahoma", Font.PLAIN, 20));
		totalInventory.setBounds(146, 24, 143, 25);
		contentPane.add(totalInventory);
		
		JButton backBtn = new JButton("Back");
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				windowMenuAdmin previousWindow = new windowMenuAdmin();
				previousWindow.setVisible(true);
				dispose();
			}
		});
		backBtn.setBounds(10, 227, 89, 23);
		contentPane.add(backBtn);
		
		JLabel label = new JLabel("Admin Controls");
		label.setBounds(10, 11, 96, 14);
		contentPane.add(label);
	}

}

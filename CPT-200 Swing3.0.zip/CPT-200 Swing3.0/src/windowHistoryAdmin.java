import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollBar;
import java.awt.event.AdjustmentListener;
import java.awt.event.AdjustmentEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class windowHistoryAdmin extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					windowHistoryAdmin frame = new windowHistoryAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public windowHistoryAdmin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserSearchHistory = new JLabel("User Search History");
		lblUserSearchHistory.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblUserSearchHistory.setBounds(130, 22, 175, 25);
		contentPane.add(lblUserSearchHistory);
		
		JLabel label = new JLabel("Admin Controls");
		label.setBounds(10, 11, 96, 14);
		contentPane.add(label);
		
		JScrollBar scrollBar = new JScrollBar();
		scrollBar.addAdjustmentListener(new AdjustmentListener() {
			public void adjustmentValueChanged(AdjustmentEvent e) 
			{
				//label.setText("This is some infoooo");
			}
		});
		scrollBar.setBounds(365, 115, 17, 65);
		contentPane.add(scrollBar);
		
		JLabel textBoxFull = new JLabel("Ford ,Truck, Black, 25MPG, non-convertible");
		textBoxFull.setBounds(97, 115, 258, 25);
		contentPane.add(textBoxFull);
		
		JLabel lblRamCoupeRed = new JLabel("RAM, Coupe, Red, 28MPG, convertible");
		lblRamCoupeRed.setBounds(97, 139, 258, 25);
		contentPane.add(lblRamCoupeRed);
		
		JLabel lblToyotaSuvWhite = new JLabel("Toyota, SUV, White, 32MPG, non-convertible");
		lblToyotaSuvWhite.setBounds(97, 161, 258, 25);
		contentPane.add(lblToyotaSuvWhite);
		
		JButton button = new JButton("Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				windowMenuAdmin previousWindow = new windowMenuAdmin();
				previousWindow.setVisible(true);
				dispose();
			}
		});
		button.setBounds(10, 227, 89, 23);
		contentPane.add(button);
	}
}

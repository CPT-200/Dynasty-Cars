import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class windowLogin {

	private JFrame frame;
	private JTextField usernameField;
	private JTextField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					windowLogin window = new windowLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public windowLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(193, 11, 48, 37);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel usernameLabel = new JLabel("Username");
		usernameLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		usernameLabel.setBounds(123, 54, 61, 14);
		frame.getContentPane().add(usernameLabel);
		
		JLabel passwordLabel = new JLabel("Password");
		passwordLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		passwordLabel.setBounds(123, 79, 61, 14);
		frame.getContentPane().add(passwordLabel);
		
		usernameField = new JTextField();
		usernameField.setBounds(243, 53, 86, 20);
		frame.getContentPane().add(usernameField);
		usernameField.setColumns(10);
		
		passwordField = new JTextField();
		passwordField.setBounds(243, 78, 86, 20);
		frame.getContentPane().add(passwordField);
		passwordField.setColumns(10);
		
		JButton loginButton = new JButton("LOGIN");
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String uname = usernameField.getText();
				String pword = passwordField.getText();
				
				if(uname.equals("name") && pword.equals("password")) {
					JOptionPane.showMessageDialog(frame, "Logged in Succesfully");
					windowMenu nextWindow = new windowMenu();
					nextWindow.setVisible(true);
					//Need to find some way to get the login frame to close upon successful login
					//windowLogin.setVisible(false);
				}
				else 
				{
					JOptionPane.showMessageDialog(frame, "Incorrect username or password. Please try again.");
				}
			}
		});
		loginButton.setBounds(175, 110, 89, 23);
		frame.getContentPane().add(loginButton);
		
		JLabel lblNewLabel_1 = new JLabel("Eventual Third Party Login");
		lblNewLabel_1.setBounds(160, 182, 126, 14);
		frame.getContentPane().add(lblNewLabel_1);
	}
}
